package com.example.Eservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
