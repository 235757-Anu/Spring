package com.example.Eservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(EserviceApplication.class, args);
	}

}
