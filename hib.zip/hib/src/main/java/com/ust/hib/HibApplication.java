package com.ust.hib;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HibApplication {

	public static void main(String[] args) {
		SpringApplication.run(HibApplication.class, args);
	}

}
