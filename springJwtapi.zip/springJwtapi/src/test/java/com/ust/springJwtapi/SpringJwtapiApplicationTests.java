package com.ust.springJwtapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringJwtapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
